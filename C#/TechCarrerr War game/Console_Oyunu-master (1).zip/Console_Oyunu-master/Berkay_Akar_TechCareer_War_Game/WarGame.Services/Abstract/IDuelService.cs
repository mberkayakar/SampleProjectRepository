﻿
using WarGame.Core.Concrete;

namespace WarGame.Services.Abstract
{
    public interface IDuelService
    {
        void StartDuello(MapRepository map);
    }
}
