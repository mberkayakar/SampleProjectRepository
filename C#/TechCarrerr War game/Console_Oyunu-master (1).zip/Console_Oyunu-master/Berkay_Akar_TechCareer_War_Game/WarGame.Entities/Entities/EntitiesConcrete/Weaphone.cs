﻿using WarGame.Entities.Abstract;

namespace WarGame.Entities.Concrete
{
    public class Weaphone : IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Damage { get; set; }




    }
}