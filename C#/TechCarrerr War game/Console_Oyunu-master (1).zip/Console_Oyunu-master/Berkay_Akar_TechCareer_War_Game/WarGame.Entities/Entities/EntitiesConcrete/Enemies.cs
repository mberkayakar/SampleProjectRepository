﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WarGame.Entities.Abstract;

namespace WarGame.Entities.Concrete
{
    public class Enemies : IEntity
    {
        public Enemies()
        {

        }
    }
}
