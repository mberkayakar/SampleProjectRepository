﻿namespace WarGame.Entities.Abstract
{
    public interface IEntity
    {
    }
}
