﻿namespace WarGame.Core.Abstract
{
    public interface IBaseMapRepository  // her bir sınıfın base sınıfı olduğu düşünülerek sürece başlanılmıştır. 
    {
        
    }
}
